var http = require('http');
http.createServer(function (req,res) {
	res.writeHead(200, {'Content-Type': 'text/plain'});
	res.end('Teach-Art.org Auctions by Havenly Blue\n');
}).listen(6166, '198.61.178.112');
console.log('handleMon Server running at 198.61.178.112:6166');